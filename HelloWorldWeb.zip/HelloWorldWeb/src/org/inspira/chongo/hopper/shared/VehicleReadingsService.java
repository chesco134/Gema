package org.inspira.chongo.hopper.shared;

public class VehicleReadingsService {
}
